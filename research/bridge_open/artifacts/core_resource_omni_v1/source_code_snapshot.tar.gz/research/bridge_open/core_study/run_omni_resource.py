"""Launch-time OmniASR resource experiment using one public API call per waveform."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import platform
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import torch

from research.bridge_open.core_study.resource_profile import (
    FIXED_PANEL_IDS,
    FIXED_PANEL_MANIFEST_SHA256,
    measure_resource_profile,
    preload_fixed_panel,
    read_fixed_panel,
    write_resource_profile,
)
from research.bridge_open.omni_extension.run_omni_full import (
    MODEL_ID,
    MODEL_REVISION,
    _load_pinned_pipeline,
    sha,
)
from research.bridge_open.omni_extension.scoring import normalize_v1, score

ROOT = Path(__file__).resolve().parents[3]


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def _packages() -> dict[str, str | None]:
    result = {}
    for name in ("torch", "fairseq2", "omnilingual-asr", "numpy", "soundfile", "jiwer", "huggingface-hub"):
        try:
            result[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            result[name] = None
    return result


def _validate_config(cfg: dict[str, Any]) -> Path:
    _require(cfg.get("experiment_kind") == "core_resource_profile", "Wrong resource experiment kind")
    _require(cfg.get("model_id") == MODEL_ID and cfg.get("model_revision") == MODEL_REVISION,
             "Omni resource profile must use the pinned Omni CTC revision")
    _require(cfg.get("device") == "cuda" and cfg.get("dtype") == "bfloat16", "Expected CUDA BF16 condition")
    _require(cfg.get("batch_size") == 1 and cfg.get("expected_count") == 12, "Expected 12-input batch-1 condition")
    _require(cfg.get("public_api") == "ASRInferencePipeline.transcribe", "Must use the official public API")
    _require(cfg.get("public_api_calls_per_input_per_phase") == 1, "Exactly one public API call is allowed per input phase")
    _require(cfg.get("warmup_passes") == 1 and cfg.get("timed_complete_passes") == 3,
             "Resource protocol requires one warmup and three timed passes")
    _require(cfg.get("quality_pass_index") == 3, "Quality must use only final timed pass")
    _require(cfg.get("timeout_seconds") == 1800 and cfg.get("gpu_flavor") == "a100-large",
             "HF job contract must remain a bounded 30-minute A100-large run")
    _require(cfg.get("gpu_contract") == "NVIDIA A100 80GB", "Unexpected GPU memory contract")
    _require(cfg.get("fixed_command") == "bash experiments/hf_entrypoint.sh", "Unexpected launch command")
    manifest = ROOT / cfg["manifest_path"]
    _require(sha(manifest) == FIXED_PANEL_MANIFEST_SHA256 == cfg.get("manifest_sha256"), "Fixed manifest hash mismatch")
    rows = read_fixed_panel(manifest)
    _require(tuple(cfg.get("conversation_ids", ())) == FIXED_PANEL_IDS, "Config IDs differ from exact fixed panel")
    _require(len(rows) == len({row["conversation_id"] for row in rows}) == 12, "Panel must contain 12 unique rows")
    for row in rows:
        for path_key, hash_key in (("audio_path", "audio_sha256"), ("reference_path", "reference_sha256")):
            path = manifest.parent / ("wav" if path_key == "audio_path" else "references") / Path(row[path_key]).name
            _require(sha(path) == row[hash_key], f"{row['conversation_id']}: {path_key} hash mismatch")
    return manifest


def _quality_records(profile: dict[str, Any], rows: tuple[dict[str, Any], ...]) -> list[dict[str, Any]]:
    final = [record for record in profile["timed_calls"] if record["pass_index"] == 3]
    _require(tuple(record["conversation_id"] for record in final) == FIXED_PANEL_IDS,
             "Final timing pass does not preserve fixed panel order")
    records = []
    for source, timed in zip(rows, final, strict=True):
        record = {"conversation_id": source["conversation_id"], "audio_sha256": source["audio_sha256"],
                  "reference_sha256": source["reference_sha256"], "timed_pass_index": 3,
                  "resource_call_status": timed["status"], "text_raw": timed["text"],
                  "text_sha256": timed["text_sha256"], "metrics": None, "failure": timed["failure"]}
        if timed["status"] == "success":
            ref_path = ROOT / "data/bridge_open/svarah_native_shard02_v2/bundle/references" / Path(source["reference_path"]).name
            reference = json.loads(ref_path.read_text())["reference_text"]
            record["text_for_scoring"] = normalize_v1(timed["text"])
            record["metrics"] = score(reference, timed["text"])
            record["status"] = "success" if record["text_for_scoring"] else "empty_output"
        else:
            record["status"] = "inference_error"
        records.append(record)
    return records


def _quality_summary(records: list[dict[str, Any]]) -> dict[str, Any]:
    scored = [record for record in records if record["metrics"] is not None]
    word_errors = sum(sum(record["metrics"][key] for key in ("substitutions", "deletions", "insertions")) for record in scored)
    words = sum(record["metrics"]["ref_words"] for record in scored)
    return {"estimand": "one final timed pass per fixed-panel utterance; no repeat averaging",
            "attempted": 12, "scored": len(scored), "runtime_failures": 12 - len(scored),
            "conversation_ids": [record["conversation_id"] for record in records],
            "micro_wer": word_errors / words if words else None, "word_errors": word_errors, "reference_words": words}


def run(config_path: str | Path) -> Path:
    config_path = Path(config_path)
    cfg = json.loads(config_path.read_text())
    manifest = _validate_config(cfg)
    _require(torch.cuda.is_available(), "CUDA is unavailable; refuse resource-profile CPU fallback")
    torch.manual_seed(cfg["seed"])
    np.random.seed(cfg["seed"])
    torch.set_num_threads(4)
    rows = read_fixed_panel(manifest)
    inputs = preload_fixed_panel(manifest)  # Decoded before model loading and timing.
    out = Path(cfg["output_dir"])
    out.mkdir(parents=True, exist_ok=False)
    (out / "config.json").write_text(json.dumps(cfg, indent=2, sort_keys=True) + "\n")
    pipeline, assets, runtime = _load_pinned_pipeline()
    _require(runtime["model_training"] is False and runtime["parameter_dtypes"] == ["torch.bfloat16"],
             "Pinned Omni model must be eval-mode BF16")

    def transcribe_one(array, sample_rate: int) -> str:
        # One official public API forward per input per phase; no token-retention or parity forward here.
        output = pipeline.transcribe([{"waveform": array, "sample_rate": sample_rate}], batch_size=1)
        if not isinstance(output, list) or len(output) != 1:
            raise RuntimeError("Official Omni public API returned an unexpected batch shape")
        return output[0]

    profile = measure_resource_profile(
        inputs, transcribe_one,
        model_residency={"model_id": MODEL_ID, "model_revision": MODEL_REVISION, "model_hashes": assets,
                         "parameter_count": runtime["parameter_count"], "declared_precision": "bfloat16",
                         "declared_search": {"decoder": "official CTC public API", "num_beams": None},
                         "resident_before_measurement": True, "runtime_evidence": runtime},
        pipeline_configuration={"batch_size": 1, "frontend": "ASRInferencePipeline public API",
                                "decoder": "ASRInferencePipeline.transcribe", "full_waveform": True,
                                "public_api_calls_per_input_per_phase": 1},
    )
    write_resource_profile(profile, out / "resource_profile.json")
    quality = _quality_records(profile, rows)
    with (out / "quality_predictions.jsonl").open("x") as stream:
        for record in quality:
            stream.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
    quality_summary = _quality_summary(quality)
    (out / "quality_summary.json").write_text(json.dumps(quality_summary, indent=2, sort_keys=True) + "\n")
    environment = {"created_at": datetime.now(timezone.utc).isoformat(), "model_id": MODEL_ID,
                   "model_revision": MODEL_REVISION, "manifest_sha256": sha(manifest), "asset_sha256": assets,
                   "runtime_evidence": runtime, "packages": _packages(), "platform": platform.platform(),
                   "python_version": platform.python_version(), "gpu": torch.cuda.get_device_name(0),
                   "torch_version": torch.__version__, "cuda_version": torch.version.cuda,
                   "config_sha256": sha(out / "config.json"),
                   "source_sha256": {str(path.relative_to(ROOT)): sha(path) for path in
                                     (Path(__file__), Path(__file__).with_name("resource_profile.py"),
                                      ROOT / "research/bridge_open/omni_extension/run_omni_full.py",
                                      ROOT / "research/bridge_open/omni_extension/scoring.py")}}
    (out / "environment.json").write_text(json.dumps(environment, indent=2, sort_keys=True) + "\n")
    return out
