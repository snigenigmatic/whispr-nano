import json
from pathlib import Path

import pytest

from experiments import hf_run
from research.bridge_open.core_study import resource_profile


ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "research/bridge_open/core_study/omni_resource_config.json"


def config():
    return json.loads(CONFIG.read_text())


def test_cpu_prepare_accepts_the_exact_verified_12_item_bundle():
    cfg = config()
    manifest = hf_run.check_inputs(cfg)
    rows = resource_profile.read_fixed_panel(manifest)
    assert len(rows) == cfg["expected_count"] == 12
    assert [row["conversation_id"] for row in rows] == cfg["conversation_ids"]


@pytest.mark.parametrize(
    ("field", "value", "message"),
    [
        ("conversation_ids", ["svarah_06413"] * 12, "Configured cohort"),
        ("public_api_calls_per_input_per_phase", 2, "exactly one official public API"),
        ("gpu_contract", "CPU", "NVIDIA A100 80GB"),
    ],
)
def test_cpu_prepare_rejects_resource_contract_changes(field, value, message):
    cfg = config()
    cfg[field] = value
    with pytest.raises(ValueError, match=message):
        hf_run.check_inputs(cfg)


def test_fixed_panel_rejects_wrong_sample_rate_before_any_model_work():
    rows = list(resource_profile.read_fixed_panel())
    rows[0]["sample_rate"] = 8000
    # A byte-altered manifest cannot pass the immutable manifest checksum either;
    # the harness therefore rejects source changes before any model is constructed.
    changed = ROOT / ".tmp-invalid-resource-manifest.jsonl"
    changed.write_text("".join(json.dumps(row) + "\n" for row in rows))
    try:
        with pytest.raises(ValueError, match="manifest bytes differ"):
            resource_profile.read_fixed_panel(changed)
    finally:
        changed.unlink()
