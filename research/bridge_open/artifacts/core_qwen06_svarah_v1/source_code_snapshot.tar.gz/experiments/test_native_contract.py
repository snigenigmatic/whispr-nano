"""CPU-only contract test for a Qwen high-level transcribe artifact."""
import hashlib
import json
import tempfile
import unittest
from types import SimpleNamespace
from pathlib import Path

from research.bridge_open.scoring import normalize_v1, score
from research.bridge_open.validate_run import validate
import research.bridge_open.validate_run as validate_module


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class NativeArtifactContractTest(unittest.TestCase):
    def test_qwen_api_artifact_validates_without_token_or_eos_claims(self):
        root = Path(__file__).resolve().parents[1]
        row = json.loads((root / "research/bridge_open/frozen_corpus_v2.jsonl").read_text().splitlines()[0])
        reference = json.loads(Path(row["reference_path"]).read_text())["reference_text"]
        raw = reference
        metrics = score(reference, raw)
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            validate_module.sf.info = lambda _: SimpleNamespace(samplerate=16000,
                channels=1, frames=round(row["duration_seconds"] * 16000))
            cfg = {
                "model_id": "Qwen/Qwen3-ASR-1.7B",
                "model_revision": "test-revision",
                "manifest_path": row["audio_path"].replace(".wav", ".jsonl"),
                "manifest_sha256": "unused",
                "conversation_ids": [row["conversation_id"]],
                "chunk_seconds": 30,
                "eos_token_ids": [151643, 151645],
                "termination_semantics": "qwen_transcribe_api",
            }
            # Use a one-row manifest so the validator exercises the complete
            # Qwen branch without requiring model weights or a GPU.
            manifest = out / "manifest.jsonl"
            manifest.write_text(json.dumps(row) + "\n")
            cfg["manifest_path"] = str(manifest)
            cfg["manifest_sha256"] = digest(manifest)
            (out / "config.json").write_text(json.dumps(cfg) + "\n")
            prediction = {
                "conversation_id": row["conversation_id"], "language": row["language"],
                "model_id": cfg["model_id"], "model_revision": cfg["model_revision"],
                "audio_sha256": row["audio_sha256"], "reference_sha256": row["reference_sha256"],
                "status": "success", "termination_semantics": "qwen_transcribe_api",
                "text_raw": raw, "text_for_scoring": normalize_v1(raw), "metrics": metrics,
                "chunks": [{"start_seconds": 0.0, "end_seconds": row["duration_seconds"],
                    "text_raw": raw, "token_evidence": "unavailable_from_transcribe_api",
                    "generation_sequences": [], "eos_present": None}],
            }
            (out / "predictions.jsonl").write_text(json.dumps(prediction, ensure_ascii=False) + "\n")
            environment = {"config_sha256": digest(out / "config.json"), "manifest_sha256": cfg["manifest_sha256"]}
            (out / "environment.json").write_text(json.dumps(environment) + "\n")
            summary = {"status": "completed", "attempted": 1, "successful": 1, "scored": 1,
                "per_language": {row["language"]: {"conversation_ids": [row["conversation_id"]],
                    "scored_count": 1, "attempted_count": 1, "word_errors": 0,
                    "ref_words": metrics["ref_words"], "character_errors": 0,
                    "ref_chars": metrics["ref_chars"], "micro_wer": 0.0, "micro_cer": 0.0,
                    "mean_conversation_wer": 0.0, "mean_conversation_wil": 0.0}}}
            (out / "summary.json").write_text(json.dumps(summary) + "\n")
            report = validate(out)
            self.assertTrue(report["valid"], report)


if __name__ == "__main__":
    unittest.main()
