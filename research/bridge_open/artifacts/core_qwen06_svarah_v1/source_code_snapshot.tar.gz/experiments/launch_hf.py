"""Reserve the shared HF budget before dispatching a prepared ORX experiment."""
import fcntl
import json
import os
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LEDGER = Path.home() / '.local/share/openresearch/whispr-bridge-open/hf-budget-20260922.json'
CAP, RESERVE = None, 1.50
ORX = str(Path.home() / '.cargo/bin/orx')


def reserve(path, key, commit):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.with_suffix('.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        ledger = json.loads(path.read_text()) if path.exists() else dict(provider='huggingface', cap_usd=CAP, reservations={})
        if ledger.get('provider') != 'huggingface':
            raise ValueError('HF ledger contract mismatch')
        ledger['cap_usd'] = CAP
        amounts = [record['reserved_usd'] for record in ledger['reservations'].values()]
        if any(amount != RESERVE for amount in amounts) or key in ledger['reservations'] or (CAP is not None and sum(amounts) + RESERVE > CAP):
            raise ValueError('Duplicate launch or HF budget exhausted')
        ledger['reservations'][key] = dict(reserved_usd=RESERVE, commit=commit, reserved_at=datetime.now(timezone.utc).isoformat(), flavor='a100-large', timeout_seconds=1800, price_per_minute_usd=.041667, provider_bill_verified=False)
        fd, tmp = tempfile.mkstemp(dir=path.parent)
        with os.fdopen(fd, 'w') as stream:
            json.dump(ledger, stream, indent=2); stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
        os.replace(tmp, path)
        return ledger


def main():
    experiment = sys.argv[1]
    def git(*args): return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
    if git('status', '--porcelain'): raise RuntimeError('Commit all code before launch')
    status, branch, commit = subprocess.check_output([ORX, 'exp', 'status', experiment], text=True), git('branch', '--show-current'), git('rev-parse', 'HEAD')
    if f'branch:   {branch}\n' not in status or 'command:  bash experiments/hf_entrypoint.sh\n' not in status or '(running,' in status or '(queued,' in status:
        raise RuntimeError('Experiment does not match the guarded execution contract')
    reserve(LEDGER, experiment + ':' + commit, commit)
    return subprocess.call([ORX, 'exp', 'run', experiment, '--backend', 'hf', '--flavor', 'a100-large', '--timeout', '30m', '--image', 'pytorch/pytorch:2.8.0-cuda12.8-cudnn9-runtime'], cwd=ROOT)


if __name__ == '__main__': raise SystemExit(main())
