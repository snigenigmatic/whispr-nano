# FLEURS Hindi Qwen3-ASR reference API benchmark

The active run_config.json is the committed three-recording post-result canary for Qwen3-ASR-1.7B, including two short recordings and the one long Hindi recording. The full configuration covers all 418 Hindi official-test recordings. Model revision, waveform/reference hashes, scorer and runtime dependencies are pinned in the committed configuration and source.

The runner calls Qwen3ASRModel.transcribe on the complete waveform with an explicit sampling rate of 16 kHz and Hindi language. It records actual model evaluation state, bfloat16 precision and greedy generation settings. Native preprocessing and chunking replace the historical manual 30-second split. The old fixed configs are retained only as history and are not accepted by this native runner.

An observation-only generate wrapper returns the original output unchanged and captures raw prompt/output tokens, EOS presence, cap-length observations and pre-parser text. The official API text remains the primary scored output, including its documented postprocessing. Output processing and precision differ from the Whisper routes and must be reported explicitly. Caps or empty text must not be silently dropped.

Calls use committed batches of up to eight recordings. The acceptance canary compares the same three recordings with the frozen serial run before full-cohort execution. All waveforms pass preflight before model loading. One native chunk per recording is required; trace and result cardinality must match the input order. EOS padding is excluded from effective token counts. Timing is measured for the complete batch, not attributed as per-record latency. Source/hash checks do not establish human transcript semantics or publication readiness.

Run only through the fixed ORX command bash experiments/hf_entrypoint.sh. Choose a condition by copying the desired JSON to research/bridge_open/run_config.json and committing on the corresponding provisional experiment branch; never vary conditions via environment variables.
