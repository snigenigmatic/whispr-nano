"""Stage exact pinned public FLEURS bytes; never regenerate audio files."""
import hashlib
import json
import tarfile
from pathlib import Path

from huggingface_hub import hf_hub_download


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def stage_reference(row, reference_pack):
    """Materialize one frozen reference after its prediction evidence exists."""
    refs = json.loads(Path(reference_pack).read_text())
    text = refs[row['conversation_id']]
    require(hashlib.sha256(text.encode()).hexdigest() == row['reference_sha256'],
            f"Frozen reference hash mismatch: {row['conversation_id']}")
    dest = Path(row['reference_path'])
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text)


def stage(rows, reference_pack, *, stage_references=True):
    """Stage archive WAV members; references may be deferred until scoring."""
    groups = {}
    for row in rows:
        require(row['source_repo'] == 'google/fleurs', f"Unexpected FLEURS source: {row['source_repo']}")
        groups.setdefault((row['source_repo'], row['source_revision'], row['source_shard'],
            row['source_archive_sha256']), []).append(row)
        if stage_references:
            stage_reference(row, reference_pack)
    for (repo, revision, shard, expected), group in groups.items():
        archive = Path(hf_hub_download(repo, shard, repo_type='dataset', revision=revision, token=False))
        require(digest(archive) == expected, f"Archive hash mismatch: {shard}")
        selected = {r['source_member']: r for r in group}
        require(len(selected) == len(group), f"Duplicate source members in {shard}")
        seen = set()
        with tarfile.open(archive, 'r:gz') as tar:
            for member in tar:
                if member.name not in selected:
                    continue
                require(member.isfile() and member.name not in seen, f"Invalid or duplicate archive member: {member.name}")
                seen.add(member.name)
                row = selected[member.name]
                extracted = tar.extractfile(member)
                require(extracted is not None, f"Archive member unreadable: {member.name}")
                data = extracted.read()
                require(hashlib.sha256(data).hexdigest() == row['audio_sha256'], f"Audio hash mismatch: {member.name}")
                dest = Path(row['audio_path'])
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
        require(seen == set(selected), f"Missing selected archive members in {shard}")
        print(json.dumps(dict(event='fleurs_sources_staged', source_shard=shard,
            archive_sha256=expected, selected_count=len(group))), flush=True)
