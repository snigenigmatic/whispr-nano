"""CPU-only negative tests for the Whisper core worker's launch guards."""
import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from experiments import hf_run


class WhisperCoreWorkerGuardsTest(unittest.TestCase):
    def test_selected_config_rejects_a_manifest_hash_mismatch(self):
        cfg = hf_run.load_selected()
        with patch("experiments.hf_run.sha", return_value="changed"):
            with self.assertRaisesRegex(ValueError, "Frozen source manifest hash changed"):
                hf_run._check_selected(cfg, Path("manifest.jsonl"))

    def test_main_emits_a_structured_failure_when_worker_raises(self):
        cfg = {"condition_id": "mock-condition"}
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch.object(hf_run, "ROOT", root), patch("experiments.hf_run.load_selected", return_value=cfg), \
                 patch("experiments.hf_run.run", side_effect=RuntimeError("mock GPU failure")), \
                 patch("experiments.hf_run.traceback.print_exc"), patch("experiments.hf_run.emit") as emit:
                self.assertEqual(hf_run.main(), 1)
                emit.assert_called_once_with(root / "artifacts" / "mock-condition")
            failure = json.loads((root / "artifacts" / "mock-condition" / "failure.json").read_text())
            self.assertEqual(failure["type"], "RuntimeError")
            self.assertIn("mock GPU failure", failure["message"])

    def test_native_short_eos_is_explicitly_unknown(self):
        import torch

        class Native:
            def parameters(self):
                yield torch.zeros(1)
            def decode(self, _mel, _options):
                return types.SimpleNamespace(tokens=[50257], text="text", avg_logprob=0.0,
                                             no_speech_prob=0.0, compression_ratio=1.0)

        whisper = types.SimpleNamespace(
            DecodingOptions=lambda **kwargs: types.SimpleNamespace(**kwargs),
            pad_or_trim=lambda audio: audio,
            log_mel_spectrogram=lambda _audio, n_mels: torch.zeros(n_mels, 3000),
        )
        result = hf_run._native_short(Native(), whisper, torch.zeros(16000).numpy(), "hi", 440)
        self.assertEqual(result["eos"]["status"], "unknown")
        self.assertEqual(result["eos"]["cap_observed"], "unknown")


if __name__ == "__main__":
    unittest.main()
