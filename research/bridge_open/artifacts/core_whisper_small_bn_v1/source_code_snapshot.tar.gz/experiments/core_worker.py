"""Prepare fixed full-cohort Whisper condition configs; no hidden environment knobs."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main() -> None:
    suite = json.loads((ROOT / "experiments/core_suite.json").read_text())
    prepared = ROOT / "prepared_conditions"
    prepared.mkdir(exist_ok=False)
    for source_name, source in suite["source_manifests"].items():
        manifest = ROOT / source["path"]
        if sha(manifest) != source["sha256"]:
            raise ValueError(f"Pinned {source_name} manifest hash changed")
        rows = [json.loads(line) for line in manifest.read_text().splitlines()]
        if len({row["conversation_id"] for row in rows}) != len(rows):
            raise ValueError(f"Duplicate {source_name} IDs")
        observed = {lang: sum(row["language"] == lang for row in rows) for lang in source["required_counts"]}
        if observed != source["required_counts"]:
            raise ValueError(f"Unexpected {source_name} language counts: {observed}")
        # Absolute original paths are evidence only. A launch must first stage
        # byte-identical data and write its own verified runtime manifest.
    for condition in suite["conditions"]:
        source = suite["source_manifests"][condition["source"]]
        rows = [json.loads(line) for line in (ROOT / source["path"]).read_text().splitlines()]
        ids = [row["conversation_id"] for row in rows if row["language"] == condition["language"]]
        if len(ids) != condition["expected_count"]:
            raise ValueError(f"{condition['condition_id']}: expected-ID mismatch")
        config = {"condition_id": condition["condition_id"], "model_id": suite["model"]["model_id"],
                  "model_revision": suite["model"]["model_revision"], "native_model": suite["model"]["native_model"],
                  "source_manifest": source["path"], "source_manifest_sha256": source["sha256"],
                  "conversation_ids": ids, "language": condition["language"], "expected_count": condition["expected_count"],
                  "max_wall_seconds": condition["max_wall_seconds"], "short_route": suite["fixed_short_route"],
                  "long_route": suite["fixed_long_route"], "runtime_manifest_required": True,
                  "reference_read_policy": "only_after_prediction_evidence", "prelaunch_parity_required": True}
        (prepared / f"{condition['condition_id']}.json").write_text(json.dumps(config, indent=2) + "\n")
    print(json.dumps({"event": "core_suite_prepared", "conditions": len(suite["conditions"])}))

if __name__ == "__main__":
    main()
