"""Five-model fixed-panel resource suite; model loading is outside each clock."""
from __future__ import annotations
import copy, gc, hashlib, importlib.metadata, json, time, traceback
from pathlib import Path
from typing import Any
import numpy as np
import torch
from huggingface_hub import snapshot_download
from research.bridge_open.core_study.resource_profile import FIXED_PANEL_IDS, FIXED_PANEL_MANIFEST_SHA256, measure_resource_profile, preload_fixed_panel, read_fixed_panel, write_resource_profile
from research.bridge_open.scoring import normalize_v1, score

ROOT = Path(__file__).resolve().parents[3]

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(ok, message):
    if not ok: raise ValueError(message)

def _roster_revision(model_id):
    roster=json.loads((ROOT/'research/bridge_open/model_roster.json').read_text())
    matches=[row['revision'] for row in roster['models'] if row['model_id']==model_id]
    require(len(matches)==1, f'roster has no unique revision for {model_id}')
    return matches[0]

def validate_config(cfg):
    require(cfg.get('experiment_kind')=='core_resource_suite', 'wrong experiment kind')
    require(cfg.get('wall_guard_seconds')==1500 and cfg.get('timeout_seconds')==1800, 'wall guard/job timeout changed')
    require(cfg.get('gpu_flavor')=='a100-large' and cfg.get('gpu_contract')=='NVIDIA A100 80GB', 'GPU contract changed')
    require(cfg.get('fixed_command')=='bash experiments/hf_entrypoint.sh', 'fixed command changed')
    manifest=ROOT/cfg['manifest_path']; require(sha(manifest)==FIXED_PANEL_MANIFEST_SHA256==cfg.get('manifest_sha256'), 'panel manifest hash changed')
    require(tuple(cfg.get('conversation_ids',()))==FIXED_PANEL_IDS, 'panel IDs/order changed')
    rows=read_fixed_panel(manifest); require(len(rows)==12 and len({r['conversation_id'] for r in rows})==12, 'panel not unique12')
    models=cfg.get('models'); require(isinstance(models,list) and len(models)==5 and len({m.get('key') for m in models})==5, 'expected five unique models')
    for spec in models:
        require(spec.get('revision')==_roster_revision(spec.get('model_id')), f"{spec.get('key')}: revision differs from roster")
        if spec.get('family')=='whisper': require(spec.get('dtype')=='float32' and spec.get('num_beams')==5, f"{spec['key']}: Whisper must be float32 beam5")
        elif spec.get('family')=='qwen': require(spec.get('dtype')=='bfloat16' and spec.get('num_beams')==1 and spec.get('language')=='English', f"{spec['key']}: Qwen must be BF16 greedy explicit English")
        else: raise ValueError(f"{spec.get('key')}: unknown model family")
    return manifest, rows

def _snapshot_hashes(model_id, revision):
    root=Path(snapshot_download(model_id, revision=revision, allow_patterns=['*.json','*.safetensors','*.txt'], token=False))
    return {p.name:sha(p) for p in sorted(root.iterdir()) if p.is_file() and p.suffix in {'.json','.txt','.safetensors'}}

def _load_whisper(spec):
    from transformers import WhisperProcessor, WhisperForConditionalGeneration
    hashes=_snapshot_hashes(spec['model_id'],spec['revision'])
    local=Path(snapshot_download(spec['model_id'],revision=spec['revision'],allow_patterns=['*.json','*.safetensors','*.txt'],token=False))
    processor=WhisperProcessor.from_pretrained(local,local_files_only=True)
    model=WhisperForConditionalGeneration.from_pretrained(local,local_files_only=True,torch_dtype=torch.float32,attn_implementation='sdpa').to('cuda').eval()
    model.generation_config.forced_decoder_ids=None
    baseline=copy.deepcopy(model.generation_config)
    search={'num_beams':5,'task':'transcribe','language':'en','do_sample':False,'return_timestamps':False,'max_new_tokens':440}
    require(not model.training and str(model.dtype)=='torch.float32','Whisper dtype/eval mismatch')
    def call(array, sr):
        model.generation_config=copy.deepcopy(baseline)
        inputs=processor([array],sampling_rate=sr,padding='max_length',max_length=480000,truncation=False,return_tensors='pt',return_attention_mask=True).to('cuda')
        with torch.inference_mode():result=model.generate(**inputs,**search)
        return processor.batch_decode(result,skip_special_tokens=True)[0]
    return call,model,hashes,{'api':'WhisperForConditionalGeneration.generate','search':search}

def _load_qwen(spec):
    from qwen_asr import Qwen3ASRModel
    hashes=_snapshot_hashes(spec['model_id'],spec['revision'])
    local=Path(snapshot_download(spec['model_id'], revision=spec['revision'], allow_patterns=['*.json','*.safetensors','*.txt'], token=False))
    qwen=Qwen3ASRModel.from_pretrained(str(local), local_files_only=True, dtype=torch.bfloat16, device_map='cuda:0', attn_implementation='sdpa', max_inference_batch_size=1, max_new_tokens=512)
    model=qwen.model.eval(); require(not model.training and str(model.dtype)=='torch.bfloat16', 'Qwen must be eval BF16')
    require(model.generation_config.do_sample is False and model.generation_config.num_beams==1, 'Qwen must be greedy')
    def call(array, sr):
        result=qwen.transcribe([(array,sr)], language=['English'], return_time_stamps=False)
        require(isinstance(result,list) and len(result)==1, 'Qwen public API cardinality mismatch')
        return result[0].text or ''
    return call, model, hashes, {'api':'Qwen3ASRModel.transcribe', 'search':{'num_beams':1,'language':'English','do_sample':False,'max_new_tokens':512}}

def _quality(profile, rows):
    final=[r for r in profile['timed_calls'] if r['pass_index']==3]
    require(tuple(r['conversation_id'] for r in final)==FIXED_PANEL_IDS, 'pass3 IDs/order changed')
    output=[]
    for row, timing in zip(rows,final,strict=True):
        record={'conversation_id':row['conversation_id'],'audio_sha256':row['audio_sha256'],'reference_sha256':row['reference_sha256'],'timed_pass_index':3,'text_raw':timing['text'],'text_sha256':timing['text_sha256'],'failure':timing['failure'],'metrics':None}
        if timing['status']=='success':
            ref=json.loads((ROOT/'data/bridge_open/svarah_native_shard02_v2/bundle/references'/Path(row['reference_path']).name).read_text())['reference_text']
            record['text_for_scoring']=normalize_v1(timing['text']); record['metrics']=score(ref,timing['text']); record['status']='success' if record['text_for_scoring'] else 'empty_output'
        else: record['status']='inference_error'
        output.append(record)
    return output

def _write_json(path, payload): Path(path).write_text(json.dumps(payload,ensure_ascii=False,sort_keys=True,indent=2)+'\n')

def run(config_path):
    cfg=json.loads(Path(config_path).read_text()); manifest, rows=validate_config(cfg)
    require(torch.cuda.is_available(), 'CUDA unavailable; no CPU fallback')
    torch.set_num_threads(4); torch.manual_seed(12); np.random.seed(12)
    inputs=preload_fixed_panel(manifest); out=Path(cfg['output_dir']); out.mkdir(parents=True,exist_ok=False); _write_json(out/'suite_config.json',cfg)
    started=time.monotonic(); summary=[]
    for spec in cfg['models']:
        item={'key':spec['key'],'model_id':spec['model_id'],'revision':spec['revision'],'status':'failed','failure':None}
        model=None; call=None
        try:
            if time.monotonic()-started>cfg['wall_guard_seconds']: raise TimeoutError('suite wall guard reached before model load')
            loader=_load_whisper if spec['family']=='whisper' else _load_qwen
            call,model,hashes,api=loader(spec)
            def guarded_call(array, sample_rate):
                if time.monotonic()-started > cfg['wall_guard_seconds']:
                    raise TimeoutError('suite wall guard reached during model profiling')
                return call(array, sample_rate)
            profile=measure_resource_profile(inputs,guarded_call,{'model_id':spec['model_id'],'model_revision':spec['revision'],'model_hashes':hashes,'parameter_count':sum(p.numel() for p in model.parameters()),'declared_precision':spec['dtype'],'declared_search':api['search'],'resident_before_measurement':True},{'batch_size':1,'frontend':'inside public API timed callable','decoder':api['api'],'public_api_calls_per_input_per_phase':1})
            _write_json(out/f"{spec['key']}_resource_profile.json",profile)
            _write_json(out/f"{spec['key']}_environment.json",{'model':spec,'model_file_sha256':hashes,
                'parameter_count':profile['model_residency']['parameter_count'],'resource_environment':profile['environment'],
                'actual_model_dtype':str(next(model.parameters()).dtype),'model_eval':not model.training,
                'packages':{name:importlib.metadata.version(name) for name in ['torch','transformers','qwen-asr','numpy','soundfile','jiwer']},
                'source_sha256':{str(path.relative_to(ROOT)):sha(path) for path in (Path(__file__),Path(__file__).with_name('resource_profile.py'),ROOT/'research/bridge_open/scoring.py',ROOT/'research/bridge_open/model_roster.json')},
                'quality_scope':'Pass 3 is scored after timing; repeated timing outputs are retained but are not additional reference observations.'})
            quality=_quality(profile,rows)
            with (out/f"{spec['key']}_quality_predictions.jsonl").open('x') as stream:
                for record in quality: stream.write(json.dumps(record,ensure_ascii=False,sort_keys=True)+'\n')
            item.update(status='completed',timed_calls=len(profile['timed_calls']),quality_records=len(quality),timed_failures=profile['summary']['timed_failed_calls'])
        except Exception as exc:
            item['failure']={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
            _write_json(out/f"{spec['key']}_failure.json",item)
        finally:
            call=None
            if model is not None: del model
            gc.collect(); torch.cuda.empty_cache(); torch.cuda.synchronize()
        summary.append(item)
    result={'schema_version':'core-resource-suite/v1','models':summary,'wall_elapsed_seconds':time.monotonic()-started,'wall_guard_seconds':cfg['wall_guard_seconds'],'hardware_claim':'Configured NVIDIA A100 80GB only; no phone-device claim.'}
    _write_json(out/'overall_summary.json',result)
    return out
